
  # Shubhaarambh Events Website

  This is a code bundle for Shubhaarambh Events Website. The original project is available at https://www.figma.com/design/u9WLDE1VeaXyILplRANIHL/Shubhaarambh-Events-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  